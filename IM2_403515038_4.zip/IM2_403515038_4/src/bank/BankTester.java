package bank;

public class BankTester {
	BankTester(){
	}
	public static void main(String[] args){
		Bank TheBank=new Bank();
		// �򥻴���
		TheBank.addAccount(1001, 0);
		TheBank.deposit(1001,500);	
		TheBank.deposit(1001,300);		
		TheBank.deposit(1001,50);	
		TheBank.withdraw(1001,500);		
		TheBank.withdraw(1001,350);		
		TheBank.closeAccount(1001);		
		
		TheBank.addAccount(1002, 0);
		TheBank.deposit(1002,2500);		
		TheBank.deposit(1002,1500);		
		TheBank.withdraw(1002,2000);	
		TheBank.withdraw(1002,500);			
		TheBank.deposit(1002,4000);			
		TheBank.suspendAccount(1002);	//Because the Balance isn't 0,so we can't close the account
		
		TheBank.addAccount(1003, 0);	
		TheBank.deposit(1003,1000);		
		TheBank.deposit(1003,100);		
		TheBank.withdraw(1003,250);		
		TheBank.deposit(1003,750);		
		TheBank.withdraw(1003,1600);	
		TheBank.closeAccount(1003);		
		// �}�߱b���@���s�ڧY�����A�᭱���ʧ@�N����q�L(Test the closeAccount method)
	/*	TheBank.addAccount(1004, 0);		
		TheBank.deposit(1004, 2000);
		TheBank.closeAccount(1004);
		TheBank.deposit(1004, 200);
		TheBank.withdraw(1004, 300);
		TheBank.deposit(1004, 800);
		TheBank.withdraw(1004, 200);	
		// �}�߱b���@���s�ڧY�ରSuspended�����g�LreOpen�~��i�����ʧ@(Test the reOpen method)
		TheBank.addAccount(1005, 0);
		TheBank.deposit(1005, 2000);
		TheBank.suspendAccount(1005);
		TheBank.deposit(1005, 200);
		TheBank.reOpenAccount(1005);
		TheBank.deposit(1005, 200);	
		TheBank.withdraw(1005, 300);
		TheBank.deposit(1005, 800);
		TheBank.withdraw(1005, 200);	
		TheBank.suspendAccount(1005);	//The balance isn't 0
		// �Y�l�B����
		TheBank.addAccount(1006, 0);
		TheBank.deposit(1006, 2000);
		TheBank.withdraw(1006, 3000);	
		TheBank.closeAccount(1006);		//I think it's reasonable to close it	
	*/	
		TheBank.summarizeAccountTransactions(1001);
		TheBank.summarizeAccountTransactions(1002);
		TheBank.summarizeAccountTransactions(1003);
	/*	TheBank.summarizeAccountTransactions(1004);
		TheBank.summarizeAccountTransactions(1005);
		TheBank.summarizeAccountTransactions(1006);
	*/	
		TheBank.summarizeAllAccounts();
	}
}
