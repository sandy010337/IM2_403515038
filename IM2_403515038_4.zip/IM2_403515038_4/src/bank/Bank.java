package bank;
import java.util.ArrayList;
class Bank{
	ArrayList<BankAccount> object_ID;
	Bank(){
		this.object_ID=new ArrayList<BankAccount>();
	}
	void addAccount(int ID, double initialBalance){
		this.object_ID.add(new BankAccount(ID,initialBalance));
		//Because add() is the type of BankAccount came from object_ID
		//we need to build a BankAccount(object) in it  
	}
	int getID(int ID){	
		for(int i=0;i<object_ID.size();i++){
			if(object_ID.get(i).ID==ID){	//KEY!!! Get the ID from object_ID of BankAccount[i](class)
				return i;					//Because ID is an integer, so we can compare it by == directly!!!
			}
		}
		return -1;
	}
	void deposit(int ID, double amount){
		int i=getID(ID);
		if(i>=0){
			object_ID.get(i).deposit(amount);
		}
	}
	void withdraw(int ID,double amount){
		int i=getID(ID);
		if(i>=0){
			object_ID.get(i).withdraw(amount);
		}
	}
	double getBalance(int ID){
		int i=getID(ID);
		if(i>=0){
			return object_ID.get(i).getbalance(ID);
		}
		else return -1;
	}
	void suspendAccount(int ID){
		int i=getID(ID);
		if(i>=0){
			object_ID.get(i).suspend();
		}
	}
	void reOpenAccount(int ID){
		int i=getID(ID);
		if(i>=0){
			object_ID.get(i).reopen();
		}
	}
	void closeAccount(int ID){
		int i=getID(ID);
		if(i>=0){
			object_ID.get(i).close();
		}	
	}
	String getAccountStatus(int ID){
		int i=getID(ID);
			return object_ID.get(i).getStatus(ID);
	}
	String summarizeAccountTransactions(int ID){
		int i=getID(ID);
		if(i>=0){
			return object_ID.get(i).getTransaction();
		}
		return "";
	}
	String summarizeAllAccounts(){
		System.out.println("Bank Account Summary\n");
		System.out.println("Account\t\tBalance\t\t#Transactions\t\tStatus");
		for(int i=0;i<object_ID.size();i++){
			int id=object_ID.get(i).ID;
			System.out.println(id+"\t\t"+object_ID.get(i).getbalance(id)+"\t\t"+object_ID.get(i).retrieveNumberOfTransactions()+"\t\t\t"+object_ID.get(i).getStatus(id));	
		}
		System.out.println("End of Account Summary");
		return "";
	}
}