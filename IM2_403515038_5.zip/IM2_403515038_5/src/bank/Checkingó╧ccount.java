package bank;

class CheckingAccount extends BankAccount {
	final int free_withdraw=3;
	double B;
	
	CheckingAccount(int ID, double Balance){
		this.B=Balance;
		this.type="checking";
	}
	void deposit(double amount){
		super.deposit(amount);
	}
	void withdraw(double amount){
		super.withdraw(amount);				
		if( withdraw_num > free_withdraw){			
			deductFees(withdraw_num);
		}
	}	
	void deductFees(int withdraw_num){								
		double FEE=2*(withdraw_num-3);		
		if(FEE < B){				
			withdraw(FEE);			
		}
		else 
			withdraw(0);							
		}
	}	