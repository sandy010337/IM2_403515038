package bank;
import java.util.ArrayList; 

public class BankAccount {
	String state,type;
	private double Balance;
	int ID, withdraw_num; 
	private ArrayList<Double> account = new ArrayList<Double>();
								
	BankAccount(){
		this(0,-1,"");
	}
	BankAccount(int ID,double Balance,String Type){
		this.state="open";
		this.Balance=Balance;
		this.ID = ID;
		this.type=Type;
	}
					
	double getbalance(int ID){			
		return this.Balance;			
	}
	int getID(){
		return this.ID;
	}
	void deposit(double amount){
		if(amount >= 0 && this.state.equals("open")){
			this.Balance+=amount;
			addTransaction(amount);			//	System.out.println("interest:::"+amount);
		}
		else if(amount<0){	System.out.println("You only can deposit the positive amount!");}
		else if(!this.state.equals("open")){	System.out.println("Please reopen the account again~");}
	}
	void withdraw(double amount){
		if(this.Balance>=0 && amount>=0 && this.state.equals("open")){
			if(amount>this.Balance){
				System.out.println("Your residual amounts isn't euough!how much you can withdraw is $"+this.Balance);
				addTransaction(this.Balance*-1);
				this.Balance=0;
				withdraw_num++;		
			}
			else{
				this.Balance-=amount;
				addTransaction(amount*-1);	
				withdraw_num++;								
			}
		}
		else{
			if(this.Balance<0){	System.out.println("You can't withdraw anymore! the Balance isn't positive");}
			else if(amount<0){	System.out.println("You only can withdraw the positive amount!");}
			else if(!this.state.equals("open")){		System.out.println("Please reopen the account again~");}
			suspend();	
		}
	}
	void suspend(){
		if(this.Balance>0){	this.state="suspended";}
	}
	void close(){
		if(!this.state.equals("closed")){
			this.state="open";
			withdraw(this.Balance);
			this.state="closed";
		}
	}
	void reopen(){
		if(this.state.equals("suspended") || this.state.equals("closed")){	this.state="open";}	
	}
	boolean isOpen(String state){
		if(this.state.equals("open")){	return true;}
		else return false;
	}
	boolean isSuspended(String state){
		if(this.state.equals("suspended")){	return true;}
		else return false;
	}
	boolean isClosed(String state){
		if(this.state.equals("closed")){	return true;}
		else return false;
	}
	void addTransaction(double amount){
		this.account.add(amount);			//System.out.println("addinterest:::"+amount);
	}
	String getTransaction(){
		System.out.println("Account #"+this.ID+" transactions:\n");
		for(int i=0;i<this.account.size();i++){	System.out.println((i+1)+": "+this.account.get(i));}	
		System.out.println("Current balance = "+this.Balance +"\n\n");
											//for(int i=0;i<this.account.size();i++) System.out.println("test::"+this.account.get(i));
		return "";
	}
	int retrieveNumberOfTransactions(){
		return this.account.size();
	}
	String getStatus(int ID){
		if(isOpen(this.state)){
			return "open";
		}
		else if(isSuspended(this.state)){
			return "suspended"; 
		}
		else	return "closed";
	}
	public boolean equals(double a){
		if(Math.abs(this.Balance-a) <= 0.1){
			return true;
		}
		else return false;
	}
	String getType(int ID){
		return this.type;
	}	
}

