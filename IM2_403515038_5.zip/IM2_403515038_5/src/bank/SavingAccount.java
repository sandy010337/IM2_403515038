package bank;

class SavingAccount extends BankAccount{
	double rate;
	
	SavingAccount(int ID,double Balance,double R){
		this.rate=R;
		this.type="savings";
	}
	void addInterest(double B){				
		double interest = B * this.rate / 100;			
		if(interest <= 0)	System.out.println("interest wrong!");
		else	super.deposit(interest);												
	}
}
