package bank;
import java.util.ArrayList;
class Bank {
	ArrayList<BankAccount> object_ID;
	Bank(){
		this.object_ID=new ArrayList<BankAccount>();
		
	}
	int getID(int ID){	
		for(int i=0;i<object_ID.size();i++){
			if(object_ID.get(i).ID==ID){	//KEY!!! Get the ID from object_ID of BankAccount[i](class)
				return i;					//Because ID is an integer, so we can compare it by == directly!!!
			}
		}
		return -1;
	}
	void deposit(int ID, double amount){
		int i=getID(ID);
		if(i>=0){
			object_ID.get(i).deposit(amount);
		}
	}
	void withdraw(int ID,double amount){
		int i=getID(ID);
		if(i>=0){
			object_ID.get(i).withdraw(amount);
		}
	}
	double getBalance(int ID){
		int i=getID(ID);
		if(i>=0){
			return object_ID.get(i).getbalance(ID);
		}
		else return -1;
	}
	void suspendAccount(int ID){
		int i=getID(ID);
		if(i>=0){
			object_ID.get(i).suspend();
		}
	}
	void reOpenAccount(int ID){
		int i=getID(ID);
		if(i>=0){
			object_ID.get(i).reopen();
		}
	}
	void closeAccount(int ID){
		int i=getID(ID);
		if(i>=0){
			object_ID.get(i).close();
		}	
	}
	String getAccountStatus(int ID){
		int i=getID(ID);
			return object_ID.get(i).getStatus(ID);
	}
	String summarizeAccountTransactions(int ID){
		int i=getID(ID);
		if(i>=0){
			return object_ID.get(i).getTransaction();
		}
		return "";
	}
	String summarizeAllAccounts(){
		System.out.println("Bank Account Summary\n");
		System.out.println("Account\t\tType\t\tBalance\t\t#Transactions\t\tStatus");
		
		for(int i=0;i<object_ID.size();i++){
			int id=object_ID.get(i).ID;
			System.out.print(id+"\t\t"+object_ID.get(i).getType(i)+"\t\t");
		//	if(object_ID.get(i) instanceof SavingAccount)	{	System.out.print("\t");}	
			System.out.println(object_ID.get(i).getbalance(id)+"\t\t"+object_ID.get(i).retrieveNumberOfTransactions()+"\t\t\t"+object_ID.get(i).getStatus(id));	
		}
		System.out.println("End of Account Summary");
		return "";
	}
	void addCheckingAccount(int ID, double initialBalance){
		this.object_ID.add(new BankAccount(ID,initialBalance,"checking"));
	}
	void addSavingsAccount(int ID,double initialBalance, double interestRate){
		this.object_ID.add(new BankAccount(ID,initialBalance,"savings"));
	}
	void addInterest(int ID){		//Only for SavingAccount
		int i =getID(ID);		
		double tmp_B=this.object_ID.get(i).getbalance(ID);
		BankAccount S=new SavingAccount(ID,tmp_B,10);
		SavingAccount SV;
		if( i>=0 ){
			SV=(SavingAccount)S;
			SV.addInterest(tmp_B);
			}
	}
	void deductFees (int ID){		//Only for CheckingAccount	
		int i=getID(ID);		
		BankAccount C =new CheckingAccount(ID,this.object_ID.get(i).getbalance(ID));
 		CheckingAccount CK;  
		if(i >= 0 ){									
 			CK=(CheckingAccount)C;
 			CK.deductFees(this.object_ID.get(i).withdraw_num);				
 			}
 	}	
	void transfer(int withdrawAcctNum,int depositAcctNum, double amount){
		int W_Num=getID(withdrawAcctNum);
		int D_Num=getID(depositAcctNum);
		if(W_Num>=0 && D_Num>=0){
			this.object_ID.get(W_Num).withdraw(amount);
			this.object_ID.get(D_Num).deposit(amount);
		}
	}
	Boolean areEqualAccounts(int ID1, int ID2){
		double a=object_ID.get(ID2).getbalance(ID2);
		if(object_ID.get(ID1).equals(a)==true){	
			return true;
		}
		else return false;
	}
}